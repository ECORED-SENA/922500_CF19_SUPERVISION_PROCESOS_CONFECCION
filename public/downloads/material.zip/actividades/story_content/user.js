function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5qnP18rrVKq":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

